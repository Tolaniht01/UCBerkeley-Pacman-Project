I have attached the entire project folder in the 'code' folder named search and contains all the scripts but only search.py and searchAgents.py is required. 



Please follow the following instructions while checking the assignment
1. Please follow all the instruction (commands) as mentioned in the question itself.
2. All the details of the implementation are given in the pdf with name Lab1_Report.
3. Please excuse if I have forgotten to comment any unnecessary Print statement.

Thank You
